from launch import LaunchDescription
from launch_ros.actions import Node

def generate_launch_description():
    return LaunchDescription([
        Node(
            package='champ_teleop',        # replace with the actual package containing teleop node
            executable='teleop_node',    # replace with the actual teleop executable
            name='teleop',
            output='screen'
        ),
    ])